from fastapi import APIRouter, HTTPException, Depends
from typing import List
from pydantic import BaseModel
from db.connection import get_db_connection

router = APIRouter()

# Define a Pydantic model for session attendance data
class SessionAttendanceData(BaseModel):
    session_id: int
    session_date: str
    attendance_status: str

@router.get("/course_attendance/{course_id}/{student_id}", response_model=List[SessionAttendanceData])
async def get_attendance_by_course_and_student(course_id: int, student_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Query to retrieve sessions and attendance status for the given course_id and student_id
    cursor.execute("""
        SELECT s.session_id, s.session_date, a.attendance_status 
        FROM sessions s
        JOIN attendance_records a ON s.session_id = a.session_id
        WHERE s.course_id = ? AND a.student_id = ?
    """, (course_id, student_id))
    
    attendance_records = cursor.fetchall()

    conn.close()

    # If no attendance records found for the given course_id and student_id, raise a 404 error
    if not attendance_records:
        raise HTTPException(status_code=404, detail="No attendance records found for the given course_id and student_id")

    # Format the attendance data into a list of dictionaries
    result = [
        {
            "session_id": row["session_id"],
            "session_date": row["session_date"],
            "attendance_status": row["attendance_status"]
        }
        for row in attendance_records
    ]

    return result