from fastapi import APIRouter, HTTPException
from typing import List
from pydantic import BaseModel
from db.connection import get_db_connection

router = APIRouter()

# Define a Pydantic model for the course response
class Course(BaseModel):
    course_id: int
    name: str

@router.get("/instructors/{instructor_id}/courses", response_model=List[Course])
async def get_instructor_courses(instructor_id: int):
    # Connect to the database
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Query to retrieve all courses given by the specified instructor
        cursor.execute("SELECT course_id, name FROM Course WHERE instructor_id = ?", (instructor_id,))
        courses = cursor.fetchall()

        # If no courses are found, raise a 404 error
        if not courses:
            raise HTTPException(status_code=404, detail="No courses found for this instructor.")

        # Create a list of course dictionaries
        course_list = [{"course_id": course[0], "name": course[1]} for course in courses]

        return course_list

    except Exception as e:
        raise HTTPException(status_code=500, detail="An error occurred while retrieving courses.")

    finally:
        conn.close()
