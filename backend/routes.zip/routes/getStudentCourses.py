from fastapi import HTTPException, APIRouter
from typing import List
from pydantic import BaseModel
from db.connection import get_db_connection

router = APIRouter()

# Define a Pydantic model for the response
class Course(BaseModel):
    course_id: int
    name: str

@router.get("/students/{student_id}/courses", response_model=List[Course])
async def get_student_courses(student_id: int):
    # Connect to the database
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Query to get course IDs for the given student ID
        cursor.execute("SELECT course_id FROM registered_courses WHERE student_id = ?", (student_id,))
        course_ids = cursor.fetchall()

        if not course_ids:
            raise HTTPException(status_code=404, detail="No courses found for this student.")

        # Extract course IDs from the fetched results
        course_ids = [course_id[0] for course_id in course_ids]

        # Construct the SQL query directly using the course IDs
        query = f"SELECT course_id, name FROM Course WHERE course_id IN ({','.join(map(str, course_ids))})"
        cursor.execute(query)
        courses = cursor.fetchall()

        if not courses:
            raise HTTPException(status_code=404, detail="No courses found.")

        # Create a list of Course objects
        course_list = [{"course_id": course[0], "name": course[1]} for course in courses]

        return course_list

    except Exception as e:
        raise HTTPException(status_code=500, detail="An error occurred while retrieving courses.")
    
    finally:
        conn.close()
