from fastapi import FastAPI, APIRouter, HTTPException
from pydantic import BaseModel
from db.connection import get_db_connection



router = APIRouter()

# Define a Pydantic model for creating a new session
class SessionCreate(BaseModel):
    course_id: int
    date: str  # You can use datetime if needed

# Helper function to connect to the database


# Endpoint to create a new course session
@router.post("/createsession")
async def create_session(session: SessionCreate):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Step 1: Insert the new session into the class_session table
        cursor.execute(
            """
            INSERT INTO class_session (course_id, date)
            VALUES (?, ?)
            """,
            (session.course_id, session.date)
        )
        conn.commit()

        # Retrieve the newly created session_id
        session_id = cursor.lastrowid

        # Step 2: Retrieve all registered students for the specified course
        cursor.execute(
            "SELECT student_id FROM registered_courses WHERE course_id = ?",
            (session.course_id,)
        )
        students = cursor.fetchall()

        # Check if any students are registered for the course
        if not students:
            raise HTTPException(status_code=404, detail="No students registered for this course.")

        # Step 3: Insert each student into the attendance_records table with status 0
        for student in students:
            cursor.execute(
                """
                INSERT INTO attendance_records (student_id, session_id, status)
                VALUES (?, ?, ?)
                """,
                (student['student_id'], session_id, "absent")
            )

        conn.commit()

        return {
            "message": "Session created successfully",
            "session_id": session_id,
            "date": session.date,
            "course_id": session.course_id,
            "registered_students": [student['student_id'] for student in students]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail="An error occurred while creating the session.")

    finally:
        conn.close()


