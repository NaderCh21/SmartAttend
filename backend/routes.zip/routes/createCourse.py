from fastapi import FastAPI, APIRouter, HTTPException
from pydantic import BaseModel
from db.connection import get_db_connection


app = FastAPI()
router = APIRouter()

# Define a Pydantic model for course creation request
class CourseCreate(BaseModel):
    instructor_id: int
    course_name: str
    course_number: str
    course_time: str
    course_schedule: str



# Endpoint to create a new course
@router.post("/courses")
async def create_course(course: CourseCreate):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Insert course data into the Course table
        cursor.execute(
            """
            INSERT INTO Course (instructor_id, course_name, course_number, course_time, course_schedule)
            VALUES (?, ?, ?, ?, ?)
            """,
            (course.instructor_id, course.course_name, course.course_number, course.course_time, course.course_schedule)
        )
        conn.commit()

        # Retrieve the newly created course_id
        course_id = cursor.lastrowid

        return {
            "message": "Course created successfully",
            "course": {
                "course_id": course_id,
                "instructor_id": course.instructor_id,
                "course_name": course.course_name,
                "course_number": course.course_number,
                "course_time": course.course_time,
                "course_schedule": course.course_schedule
            }
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail="An error occurred while creating the course")

    finally:
        conn.close()

