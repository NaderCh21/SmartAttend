from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from db.connection import get_db_connection
from passlib.hash import bcrypt
router = APIRouter()

# Define a Pydantic model for the login data
class LoginData(BaseModel):
    email: str
    password: str

@router.post("/login")



async def login(data: LoginData):
    email = data.email
    password = data.password

    # Get database connection
    conn = get_db_connection()
    cursor = conn.cursor()

    # Query to fetch user information from the authentication table
    cursor.execute("SELECT ID, password, role FROM authentication WHERE email = ?", (email,))
    user = cursor.fetchone()

    # Close connection
    conn.close()

    if user:
        user_id, hashed_password, role = user

        # Check if the password matches
        if bcrypt.verify(password, hashed_password):
            if role == "student":
                return {"message": "Student Login successful", "user_id": user_id}
            elif role == "instructor":
                return {"message": "Instructor Login successful", "user_id": user_id}
            else:
                raise HTTPException(status_code=400, detail="Unknown user role")

        else:
            raise HTTPException(status_code=400, detail="Invalid password")

    else:
        raise HTTPException(status_code=400, detail="Invalid email or password")
