from fastapi import APIRouter, HTTPException, Depends
from typing import List
from pydantic import BaseModel
from db.connection import get_db_connection

router = APIRouter()

# Define a Pydantic model for student attendance data
class StudentAttendanceData(BaseModel):
    student_id: int
    student_name: str
    attendance_status: str

@router.get("/session_attendance/{session_id}", response_model=List[StudentAttendanceData])
async def get_student_attendance(session_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Query to retrieve student names, IDs, and attendance status for the given session_id
    cursor.execute("""
        SELECT s.student_id, s.student_name, a.attendance_status 
        FROM students s
        JOIN attendance_records a ON s.student_id = a.student_id
        WHERE a.session_id = ?
    """, (session_id,))
    attendance_records = cursor.fetchall()

    conn.close()

    # If no attendance records found for the session_id, raise a 404 error
    if not attendance_records:
        raise HTTPException(status_code=404, detail="No attendance records found for the given session_id")

    # Format the attendance data into a list of dictionaries
    result = [
        {
            "student_id": row["student_id"],
            "student_name": row["student_name"],
            "attendance_status": row["attendance_status"]
        }
        for row in attendance_records
    ]

    return result