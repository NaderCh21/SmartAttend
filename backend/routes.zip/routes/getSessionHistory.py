from fastapi import APIRouter, HTTPException, Depends
from typing import List
from pydantic import BaseModel
from db.connection import get_db_connection

router = APIRouter()

# Define a Pydantic model for session data
class SessionData(BaseModel):
    session_id: int
    course_id: int
    session_date: str

@router.get("/sessions/{course_id}", response_model=List[SessionData])
async def get_sessions(course_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()

    # Query to retrieve all sessions for the given course_id
    cursor.execute("SELECT session_id, course_id, session_date FROM sessions WHERE course_id = ?", (course_id,))
    sessions = cursor.fetchall()

    conn.close()

    # If no sessions found for the course_id, raise a 404 error
    if not sessions:
        raise HTTPException(status_code=404, detail="No sessions found for the given course_id")

    # Format the session data into a list of dictionaries
    result = [
        {
            "session_id": row["session_id"],
            "course_id": row["course_id"],
            "session_date": row["session_date"]
        }
        for row in sessions
    ]

    return result
