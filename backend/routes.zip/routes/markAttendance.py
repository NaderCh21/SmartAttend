from fastapi import FastAPI, APIRouter, HTTPException
from pydantic import BaseModel
from db.connection import get_db_connection


router = APIRouter()

# Define a Pydantic model for updating attendance status
class AttendanceUpdate(BaseModel):
    student_id: int
    session_id: int

# Helper function to connect to the database
def get_db_connection():
    import sqlite3
    conn = sqlite3.connect("database.db")  # Replace with your database connection
    conn.row_factory = sqlite3.Row
    return conn

# Endpoint to update attendance status
@router.put("/markattendance")
async def update_attendance(attendance: AttendanceUpdate):
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if the record exists before updating
        cursor.execute(
            "SELECT status FROM attendance_records WHERE student_id = ? AND session_id = ?",
            (attendance.student_id, attendance.session_id)
        )
        record = cursor.fetchone()

        if record is None:
            raise HTTPException(status_code=404, detail="Attendance record not found.")

        # Update the attendance status to 1 (indicating present)
        cursor.execute(
            "UPDATE attendance_records SET status = ? WHERE student_id = ? AND session_id = ?",
            ("present", attendance.student_id, attendance.session_id)
        )

        conn.commit()

        return {"message": "Attendance status updated successfully."}

    except Exception as e:
        raise HTTPException(status_code=500, detail="An error occurred while updating the attendance status.")

    finally:
        conn.close()


