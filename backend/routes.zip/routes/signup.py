from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from db.connection import get_db_connection
from passlib.hash import bcrypt
router = APIRouter()


# Pydantic model for signup request data
class SignupData(BaseModel):
    email: str
    password: str
    first_name: str
    last_name: str
    role: str  # "student" or "instructor"
    phonenumb: str

@router.post("/signup")
async def signup(data: SignupData):
    email = data.email
    password = data.password
    first_name = data.first_name
    last_name = data.last_name
    role = data.role
    phonenumb = data.phonenumb

    # Hash the password
    hashed_password = bcrypt.hash(password)

    # Connect to the database
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Insert user into authentication table
        cursor.execute(
            "INSERT INTO authentication (email, password, role) VALUES (?, ?, ?)",
            (email, hashed_password, role)
        )
        
        # Retrieve the auto-incremented ID of the newly created user
        user_id = cursor.lastrowid

        # Insert into the appropriate table
        if role == "student":
            cursor.execute(
                "INSERT INTO student (student_id, first_name, last_name, email, phonenumb) VALUES (?, ?, ?)",
                (user_id, first_name, last_name, email, phonenumb)
            )
        elif role == "instructor":
            cursor.execute(
                "INSERT INTO instructor (instructor_id, first_name, last_name) VALUES (?, ?, ?)",
                (user_id, first_name, last_name, email, phonenumb)
            )

        # Commit the transaction
        conn.commit()

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail="An error occurred during registration.")

    finally:
        conn.close()

    return {"message": f"{role.capitalize()} registered successfully"}
