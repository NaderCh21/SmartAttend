from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List
from db.connection import get_db_connection

router = APIRouter()

# Define a Pydantic model for the course registration request
class CourseRegistration(BaseModel):
    student_id: int
    course_id: int

@router.post("/register_course")
async def register_course(data: CourseRegistration):
    # Extract student ID and course ID from the request data
    student_id = data.student_id
    course_id = data.course_id

    # Connect to the database
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if the course exists
        cursor.execute("SELECT id FROM Course WHERE id = ?", (course_id,))
        course = cursor.fetchone()
        if not course:
            raise HTTPException(status_code=404, detail="Course not found.")

        # Check if the student is already registered for the course
        cursor.execute("SELECT * FROM registered_courses WHERE student_id = ? AND course_id = ?", (student_id, course_id))
        existing_registration = cursor.fetchone()
        if existing_registration:
            raise HTTPException(status_code=400, detail="Student is already registered for this course.")

        # Register the student for the course
        cursor.execute("INSERT INTO registered_courses (student_id, course_id) VALUES (?, ?)", (student_id, course_id))
        conn.commit()

        return {"message": "Course registered successfully."}

    except Exception as e:
        raise HTTPException(status_code=500, detail="An error occurred while registering the course.")

    finally:
        conn.close()
